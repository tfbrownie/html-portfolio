<header class="d-flex justify-content-center py-3">
      <ul class="nav nav-pills">
        <li class="nav-item"><a href="../Products/Jerseys.php" class="nav-link " aria-current="page">Jerseys</a></li>
        <li class="nav-item"><a href="../Products/shoes.php" class="nav-link">Shoes</a></li>
        <li class="nav-item"><a href="../Products/Hats.php" class="nav-link">Hats</a></li>
        <li class="nav-item"><a href="../Products/tShirts.php" class="nav-link">T-Shirts</a></li>
      </ul>
    </header>