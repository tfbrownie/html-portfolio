<?php 
	$db = mysqli_connect("localhost","u563120212_root","mysqlPHP1", "u563120212_fsgDatabase") or die("Couldn't connect to SQL server");
	$mysqli = new mysqli("localhost", "u563120212_root","mysqlPHP1", "u563120212_fsgDatabase");
?>