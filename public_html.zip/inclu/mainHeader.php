<!-- <?php
//include ("/Check_connection.php");
//include ("../SQL/signUp.php");
?>
<nav class="py-2 bg-body-tertiary border-bottom">
    <div class="container d-flex flex-wrap">
      <ul class="nav me-auto">
        <li class="nav-item"><a href="#" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
        <li class="nav-item"><a href="#" class="nav-link link-body-emphasis px-2">Features</a></li>
        <li class="nav-item"><a href="#" class="nav-link link-body-emphasis px-2">About</a></li>
      </ul>
	  
      <ul class="nav">
     /* <?php
                   
					if ($user!="") {
						echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
					}
					else {
						echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
        		echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
					}
				 ?>
         */
      </ul>
    </div>
  </nav> -->