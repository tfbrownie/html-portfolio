<?php include("../inclu/Check_connection.php"); ?>
<?php

if (isset($_REQUEST['poid'])) {

	$poid = mysqli_real_escape_string($db, $_REQUEST['poid']);
} else {
	//header('location: index.php');
}
ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
	$user = "";
	//header("location: login.php?ono=".$poid."");
} else {
	$user = $_SESSION['user_login'];
	$result = mysqli_query($db, "SELECT * FROM user WHERE email='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
	$uemail_db = $get_user_email['email'];

	$umob_db = $get_user_email['mobile'];
	$uadd_db = $get_user_email['address'];
	$user_id = $get_user_email['id'];
}


$getposts = mysqli_query($db, "SELECT * FROM products WHERE id ='$poid'") or die(mysqli_error($db));
if (mysqli_num_rows($getposts)) {
	$row = mysqli_fetch_assoc($getposts);
	$id = $row['id'];
	$pName = $row['pName'];

	$price = $row['price'];
	$description = $row['description'];
	$picture = $row['picture'];
	$size = $row['size'];
	$category = $row['category'];
	$available = $row['available'];
}

//order

if (isset($_POST['order'])) {
	//declere veriable
	$mbl = $_POST['mobile'];
	$addr = $_POST['address'];
	$quan = $_POST['quantity'];
	//triming name
	try {
		if (empty($_POST['mobile'])) {
			throw new Exception('Mobile can not be empty');
		}
		if (empty($_POST['address'])) {
			throw new Exception('Address can not be empty');
		}
		if (empty($_POST['quantity'])) {
			throw new Exception('Quantity cannot be 0');
		}


		// Check if email already exists


		$d = date("Y-m-d"); //Year - Month - Day
		$timestamp = time();
		$date = strtotime("+7 day", $timestamp);
		$date = date('Y-m-d', $date);

		// send email
		$msg = "
						
						
						";


		if (mysqli_query($db, "INSERT INTO orders (uid,pid,quantity,oplace,mobile,odate,ddate) VALUES ('$user_id','$poid',$quan,'$_POST[address]','$_POST[mobile]','$d','$date')")) {

			//success message
			$success_message = '
						<div class="col-md-12 col-lg-12"><h2><font face="bookman">Your order was placed successfully</font></h2>
						<div class="signupform_text" style="font-size: 18px; text-align: center;">
						<font face="bookman">
							This can now be seen in your history
							<br> Enjoy your gear!
						</font></div></div>';
		} else {
			$error_message = 'Something went wrong';
		}
	} catch (Exception $e) {
		$error_message = $e->getMessage();
	}
}


?>

<!DOCTYPE html>
<html>

<head>
	<title>Order Form</title>
	<link href="styles.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
	<div class="homepageheader">
		<div class="container d-flex flex-wrap">
			<ul class="nav me-auto">
				<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
				<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
				<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
			</ul>

			<ul class="nav">
				<?php

				if ($user != "") {
					echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
					echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
				} else {
					echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
					echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
				}
				?>
			</ul>
		</div>
		<? include("../inclu/menuHeader.php"); ?>

		
	</div>

	<div class="row" style=" padding-top: 20px; padding: 0 20%">
		<main>
			<div class="container signupform_content ">
				<div class="col-lg-10">
					<h2 style="padding-bottom: 20px; text-align: center;">Checkout Form</h2>
					<div style="float: right;">
						<?php
						if (isset($success_message)) {
							echo $success_message;
						} else {
							echo '
						<div class="col-md-12 col-lg-12">
						
						
						<form action="" method="POST" class="registration">
						
							<div class="col-lg-10">
								<td>
									<input name="mobile" placeholder="Your mobile number" required="required" class="form-control  col-12 type="text" value="' . $umob_db . '">
								</td>
							</div>
							<div class="col-lg-10">
								<td>
									<input name="address" id="password-1" required="required"  placeholder="Write your full address" class="form-control" type="text" value="' . $uadd_db . '">
								</td>
							</div>
							<div>
								<td>
									<select  class="form-select mb-3 col-md-5" onchange="changeAmount()" name="quantity" required="required" id="productAmount" >'



						?><?php
							for ($i = 1; $i <= $available; $i++) {
								echo '<label for="quantity">Pick a Quantity:</label>
											
											<option  value="' . $i . '">Quantity: ' . $i . '</option>';
							}
							function totalPrice()
							{
								global $total;
								global $price;
								global $i;
								$total = $i * $price;
								if ($i <= 1) {
									$total = $price;
									return $total;
								} else {
									return '$' . $total;
								}
							}
							?>
						<?php echo '
									</select>
								</td>
							</div>
							<div class="col-md-5">
								<input name="order" class="btn btn-primary" type="submit" value="Confirm Order">
							</div>
							<div class="signup_error_msg"> '; ?>
						<?php
							if (isset($error_message)) {
								echo $error_message;
							}

						?>
					<?php echo '</div>
						</div>
					</form>
							
						
					</div>

					';
						}

					?>

					</div>
				</div>

				<div style="float: left; font-size: 23px;">
					<div>
						<?php
						echo '
						<div class="col-md-6 col-lg-6 order-md-last">
						<ul style="list-style: none;  float: left;">
						<li style="float: left; padding: 0px 25px 25px 25px;">
						<div class="card shadow-sm"><a href="viewProducts.php?pid=' . $id . '">						
						<img  src = "../Images/Product Images/' . $picture . '"  style="width:500px;height:600px;" class="home-prodlist-imgi"></a>
						<div style="text-align: center; padding: 0 0 6px 0;">
						  <span style="font-size: 15px;">' . $pName . '</span><br> Price:$  <span id="amountText">' . $price . '</span>  <span id="aHiddenText" style="display:none">' . $price . '</span> <br> ' . $size . '
						  
							
							</div>
						</div>
					  </li>
						</ul>
						</div>
					';
						?>
					</div>

				</div>
			</div>
	</div>
	</main>



	<script type="text/javascript">
		function changeAmount() {
			var v = document.getElementById("aHiddenText").innerHTML;
			document.getElementById("amountText").innerHTML = v;
			var sBox = document.getElementById("productAmount");
			var y = sBox.value;
			var x = document.getElementById("amountText").innerHTML;
			var y = parseInt(y);
			var x = parseInt(x);
			document.getElementById("amountText").innerHTML = x + "x" + y + " = $" + x * y;
		}
	</script>

	<?php include("../inclu/footer.php"); ?>