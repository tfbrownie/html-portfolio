<?php include("../inclu/Check_connection.php"); ?>
<?php

ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
	header("location: login.php");
} else {
	$user = $_SESSION['user_login'];
	$result = mysqli_query($db, "SELECT * FROM user WHERE email='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
	$uemail_db = $get_user_email['email'];

	$umob_db = $get_user_email['mobile'];
	$uadd_db = $get_user_email['address'];
	$user_id = $get_user_email['id'];
}

// if (isset($_REQUEST['uid'])) {

// 	$user2 = mysqli_real_escape_string($db,$_REQUEST['uid']);
// 	if($user != $user2){
// 		header('location: index.php');
// 	}
// }else {
// 	//header('location: index.php');
// }

$search_value = "";
?>

<!DOCTYPE html>
<html>

<head>
	<title>Orders</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="styles.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body style="background-image: url(image/homebackgrndimg1.png);">
	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav me-auto">
				<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
				<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
				<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
			</ul>

			<ul class="nav">
				<?php

				if ($user != "") {
					echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
					echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
				} else {
					echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
					echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
				}
				?>
			</ul>
		</div>
	</nav>
	<? include("../inclu/menuHeader.php"); ?>


	<h3 style="text-align: center">Your Past Orders</h3>

	<div class="text-center" style="margin-top: 20px;">
		<div class="container">

			<ul style="list-style: none;">

				</li>
				<li style="width: 90%">
					<div class="row justify-content-center">
						<div class="col-auto">
							<table class="table table-bordered">
								<thead>
									<tr style="font-weight: bold;">
										<th scope="col">Product Name</th>
										<th scope="col">Price</th>
										<th scope="col">Total Product</th>
										<th scope="col">Order Date</th>
										<th scope="col">Delevery Date</th>
										<th scope="col">Delevery Place</th>
										<!-- <th scope="col">Delevery Status</th> -->
										<th scope="col">View</th>
									</tr>
								</thead>
								<tbody>
									<tr style="font-weight: bold; width: 100%;   padding: 15px;" colspan="10" ;>
										<?php
										$query = "SELECT * FROM orders WHERE uid='$user_id' ORDER BY id DESC";
										$run = mysqli_query($db, $query);
										while ($row = mysqli_fetch_assoc($run)) {
											$pid = $row['pid'];
											$quantity = $row['quantity'];
											$oplace = $row['oplace'];
											$mobile = $row['mobile'];
											$odate = $row['odate'];
											$ddate = $row['ddate'];
											$dstatus = $row['dstatus'];

											//get product info
											$query1 = "SELECT * FROM products WHERE id='$pid'";
											$run1 = mysqli_query($db, $query1);
											$row1 = mysqli_fetch_assoc($run1);
											$pId = $row1['id'];
											$pName = substr($row1['pName'], 0, 50);
											$price = $row1['price'];
											$picture = $row1['picture'];
											$size = $row1['size'];
											$category = $row1['category'];
										?>
											<th><?php echo $pName; ?></th>
											<th><?php echo $price; ?></th>
											<th><?php echo $quantity; ?></th>
											<th><?php echo $odate; ?></th>
											<th><?php echo $ddate; ?></th>
											<th><?php echo $oplace; ?></th>
											<!-- <th><?php echo $dstatus; ?></th> -->
											<th><?php echo '<div class="home-prodlist-img">
													<img src="../Images/Product Images/' . $picture . '" class="home-prodlist-imgi" style="height: 75px; width: 75px;">
												</div>' ?></th>
									</tr>
								<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</div>
	</div>


	<?php include("../inclu/footer.php"); ?>