<?php include("../inclu/Check_connection.php");

ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
	$user = "";
} else {
	$user = $_SESSION['user_login'];
	$result = mysqli_query($db, "SELECT * FROM user WHERE email='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
}
if (isset($_REQUEST['pid'])) {

	$pid = mysqli_real_escape_string($db, $_REQUEST['pid']);
} else {
	//echo "$pid is not set";
}


$getposts = mysqli_query($db, "SELECT * FROM products WHERE id ='$pid'") or die(mysqli_error($db));
if (mysqli_num_rows($getposts)) {
	$row = mysqli_fetch_assoc($getposts);
	$id = $row['id'];
	$pName = $row['pName'];
	$price = $row['price'];
	$description = $row['description'];
	$picture = $row['picture'];
	$size = $row['size'];
	$available = $row['available'];
}

?>

<!DOCTYPE html>
<html>

<head>
	<title>FSG Products</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="styles.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
	<div class="container d-flex flex-wrap">
		<ul class="nav me-auto">
			<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
			<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
			<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
		</ul>

		<ul class="nav">
			<?php

			if ($user != "") {
				echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
				echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
			} else {
				echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
				echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
			}
			?>
		</ul>
	</div>
	<?php include("../inclu/menuHeader.php"); ?>


	<div style="margin: 0 97px; padding: 10px">

		<?php
		echo '
			<div class="text-bg-dark me-md-3 pt-3 px-3 pt-md-5 px-md-5 text-center overflow-hidden">
			<div class="my-3 py-3">
			  <h2 class="display-5">' . $pName . '</h2>
			  <p class="lead">' . $description . '</p>
			  <p class="lead">Size: ' . $size . '</p>
		  <p class="lead">$' . $price . '</p>
			</div>
			<img src="../Images/Product Images/' . $picture . '" class="bg-body-tertiary shadow-sm mx-auto" style="width: 80%; height: auto; border-radius: 21px 21px 0 0;">
		  </div>
		  <div class="col-lg-6 col-xxl-4 my-5 mx-auto">
		  <div class="d-grid gap-2">
			<a href = "http://localhost/PHP%20Test%20Site/Products/Jerseys.php" ><button style = "width: 100%" class="btn btn-outline-secondary" type="button">View More Jerseys</button></a>

		
			<form id="" method="post" action="../Products/orderForm.php?poid=' . $pid . '">
			<button style ="width: 100%;" class="btn btn-outline-primary" type="submit"> Order Now
			</button>
			</form>
		
		  </div>
		</div>

					</div>
				</div>

			';
		?>

	</div>
	<div style="padding: 30px 95px; font-size: 25px; margin: 0 auto; display: table; width: 98%;">
		<h3 style="padding-bottom: 20px">Suggested Product</h3>
		<div>
			<?php
			$getposts = mysqli_query($db, "SELECT * FROM products WHERE available >='1' AND id != '" . $pid . "' AND pName !='" . $pName . "'  ORDER BY RAND() LIMIT 1") or die(mysqli_error($db));
			if (mysqli_num_rows($getposts)) {
				echo '<ul id="recs">';
				while ($row = mysqli_fetch_assoc($getposts)) {
					$id = $row['id'];
					$pName = $row['pName'];
					$price = $row['price'];
					$description = $row['description'];
					$picture = $row['picture'];

					echo '
						<div class "row-cols-1 row-cols-sm-2 row-cols-md-3 g-3 col-3">
						<div class="col-3">
						<div class="card shadow-sm">
				  			<a href="viewProducts.php?pid=' . $id . '">	
						  <img src = "../Images/Product Images/' . $picture . '"  class="rounded float-start img-fluid" alt="Jersey for sale">
						  <div class="card-body">
							<p class="card-text">' . $pName . '</p>
							
							<div class="d-flex justify-content-between align-items-center">
							  <div class="btn-group">
								<button type="button" class="btn btn-sm btn-outline-secondary">View</button>
								</a>
								</div>
								<div>
								<button type="button" class="btn btn-sm btn-outline-secondary">' . $size . '</button>
								<button type="button" class="btn btn-sm btn-outline-secondary">Price: $' . $price . '</button>
							  </div>
							  
							</div>
							
			  				</div>
						</div>
					  </div>
					  </div>					
						';
				}
			}
			?>

		</div>
	</div>
	<?php
	include("../inclu/footer.php");
	?>
</body>

</html>