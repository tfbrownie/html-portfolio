<?php include("../inclu/Check_connection.php"); ?>
<?php
ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
	$user = "";
} else {
	$user = $_SESSION['user_login'];
	$result = $mysqli->query("SELECT * FROM user WHERE email='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>Jerseys</title>
	<link href="styles.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav me-auto">
				<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
				<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
				<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
			</ul>

			<ul class="nav">
				<?php

				if ($user != "") {
					echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
					echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
				} else {
					echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
					echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
				}
				?>
			</ul>
		</div>
	</nav>
	<? include("../inclu/menuHeader.php"); ?>
	<h3 style="text-align: center">FSG Jerseys</h3>

	<div style="padding: 30px 120px; font-size: 25px; margin: 0 auto; display: table; width: 98%;">
		<div class="container">
			<?php
			$getposts = $mysqli->query("SELECT * FROM products WHERE available >='1' AND category ='Jerseys'  ORDER BY id DESC ") or die();

			if (mysqli_num_rows($getposts)) {
			?>
				<ul id="recs"><?php
								while ($row = mysqli_fetch_assoc($getposts)) {
									$id = $row['id'];
									$pName = $row['pName'];
									$price = $row['price'];
									$description = $row['description'];
									$picture = $row['picture'];
									$size = $row['size'];
									$category = $row['category'];

									echo '
						<ul style="list-style: none;  float: left;">
						<li style="float: left; padding: 0px 25px 25px 25px;">
							<div class="card shadow-sm"><a href="viewProducts.php?pid=' . $id . '">
								<img src = "../Images/Product Images/' . $picture . '"  style="width:500px;height:600px;" alt="Jersey for sale">
								</a>
								<div style="text-align: center; padding: 0 0 6px 0;"> <span style="font-size: 30px;">' . $pName . '</span><br> Price: $' . $price . '
								<br> ' . $size . ' </div>
							</div>
							
						</li>
					</ul>
						
						
					  					
					';
								}
							}
								?>

		</div>
	</div>

	<?php include("../inclu/footer.php") ?>