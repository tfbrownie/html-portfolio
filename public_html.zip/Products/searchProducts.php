<?php
include("../inclu/Check_connection.php");
//include ("../inclu/mainHeader.php");
//include ("../inclu/menuHeader.php");

ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
  $user = "";
} else {
  $user = $_SESSION['user_login'];
  $result = $mysqli->query("SELECT * FROM user WHERE email='$user'");
  $get_user_email = mysqli_fetch_assoc($result);
  $uname_db = $get_user_email['firstName'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="styles.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>FSG Products</title>
</head>

<body>
  <nav class="py-2 bg-body-tertiary border-bottom">
    <div class="container d-flex flex-wrap">
      <ul class="nav me-auto">
        <li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
        <li class="nav-item"><a href="../Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
        <li class="nav-item"><a href="#" class="nav-link link-body-emphasis px-2">About</a></li>
      </ul>

      <ul class="nav">
        <?php

        if ($user != "") {
          echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
          echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
        } else {
          echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
          echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
        }
        ?>
      </ul>
    </div>
  </nav>
  <? include("../inclu/menuHeader.php"); ?>
  <div class="row mb-3 text-center">
    <div class="col-lg-4 themed-grid-col">.col-lg-4</div>
    <div class="col-lg-4 themed-grid-col">.col-lg-4</div>
    <div class="col-lg-4 themed-grid-col">.col-lg-4</div>
  </div>

  <? include("../inclu/footer.php");
  ?>