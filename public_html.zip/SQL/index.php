<?php
include("../inclu/Check_connection.php");
//include ("../inclu/mainHeader.php");
//include ("../inclu/menuHeader.php");

ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
  $user = "";
} else {
  $user = $_SESSION['user_login'];
  $result = $mysqli->query("SELECT * FROM user WHERE email='$user'");
  $get_user_email = mysqli_fetch_assoc($result);
  $uname_db = $get_user_email['firstName'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="styles.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>FSG Home</title>
</head>

<body>
  <nav class="py-2 bg-body-tertiary border-bottom">
    <div class="container d-flex flex-wrap">
      <ul class="nav me-auto">
        <li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active fw-bolder" aria-current="page">Home</a></li>
        <li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
        <li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
      </ul>

      <ul class="nav">
        <?php

        if ($user != "") {
          echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
          echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
        } else {
          echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
          echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
        }
        ?>
      </ul>
    </div>
  </nav>
  <? include("../inclu/menuHeader.php"); ?>
  <div class="row d-flex flex-column flex-md-row p-4 gap-4 py-md-5 align-items-center justify-content-center">
    <div class="album py-5 bg-body-tertiary">
      <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

          <div class="col">
            <div class="card shadow-sm">
              <img src="../Images/Website Images/adminstrator.jpg" class="rounded float-start" alt="Administrator">
              <div class="card-body">
                <h3>Sign in as Admin</h3>
                <p class="card-text">Administrators can list products and enable other administrators</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="../admin/adminLogIn.php">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Join the Team</button>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img src="../Images/Website Images/open box.jpg" class="rounded float-start" alt="open box">
              <div class="card-body">
                <h3>Ordering History</h3>
                <p class="card-text">Look at your past orders.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="../Products/pastOrders.php"> <button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img src="../Images/Product Images/REGGIEWHITE.jpg" class="rounded float-start" alt="Reggie White Jersey">
              <div class="card-body">
                <h3>Shop Online</h3>
                <p class="card-text">Browse products and place more orders!</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="../Products/allProducts.php"><button type="button" class="btn btn-sm btn-outline-secondary">View available products</button></a>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
      <div class="container">
        <span>
          <h3 class="">Disclaimer</h3>
          <p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
        </span>
      </div>
    </footer>

    <script src="movement.js" charset="utf-8"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>