<?php include("../inclu/Check_connection.php");

ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
} else {
	header("location: index.php");
}
$emails = "";
$passs = "";
if (isset($_POST['login'])) {
	if (isset($_POST['email']) && isset($_POST['password'])) {
		$user_login = mysqli_real_escape_string($db, $_POST['email']);
		//$user_login = mb_convert_case($user_login, MB_CASE_LOWER, "UTF-8");	
		$password_login = mysqli_real_escape_string($db, $_POST['password']);
		$num = 0;
		$password_login_md5 = md5($password_login);
		$result = mysqli_query($db, "SELECT * FROM user WHERE (email='$user_login') AND password='$password_login_md5' AND activation='yes'");
		$num = mysqli_num_rows($result);
		$get_user_email = mysqli_fetch_assoc($result);
		$get_user_uname_db = $get_user_email['email'];
		if ($num > 0) {
			$_SESSION['user_login'] = $get_user_uname_db;
			setcookie('user_login', $user_login, time() + (365 * 24 * 60 * 60), "/");

			if (isset($_REQUEST['ono'])) {
				$ono = mysqli_real_escape_string($db, $_REQUEST['ono']);
				header("location: orderform.php?poid=" . $ono . "");
			} else {
				header('location: index.php');
			}
			exit();
		} else {
			$result1 = mysqli_query($db, "SELECT * FROM user WHERE (email='$user_login') AND password='$password_login_md5' AND activation='no'");
			$num1 = mysqli_num_rows($result1);
			$get_user_email1 = mysqli_fetch_assoc($result1);
			$get_user_uname_db1 = $get_user_email1['email'];
			if ($num1 > 0) {
				$emails = $user_login;
				$activacc = '';
			} else {
				$emails = $user_login;
				$passs = $password_login;
				$error_message = '<br><br>
				<div class="maincontent_text" style="text-align: center; font-size: 18px;">
				<font face="bookman">Email or Password incorrect.<br>
				<?php echo $num; ?>
				</font></div>';
			}
		}
	}
}
$acemails = "";
$acccode = "";
if (isset($_POST['activate'])) {
	if (isset($_POST['actcode'])) {
		$user_login = mysqli_real_escape_string($con, $_POST['acemail']);
		$user_login = mb_convert_case($user_login, MB_CASE_LOWER, "UTF-8");
		$user_acccode = mysqli_real_escape_string($con, $_POST['actcode']);
		$result2 = mysqli_query($con, "SELECT * FROM user WHERE (email='$user_login') AND confirmCode='$user_acccode'");
		$num3 = mysqli_num_rows($result2);
		echo $user_login;
		if ($num3 > 0) {
			$get_user_email = mysqli_fetch_assoc($result2);
			$get_user_uname_db = $get_user_email['id'];
			$_SESSION['user_login'] = $get_user_uname_db;
			setcookie('user_login', $user_login, time() + (365 * 24 * 60 * 60), "/");
			mysqli_query($con, "UPDATE user SET confirmCode='0', activation='yes' WHERE email='$user_login'");
			if (isset($_REQUEST['ono'])) {
				$ono = mysqli_real_escape_string($con, $_REQUEST['ono']);
				header("location: orderform.php?poid=" . $ono . "");
			} else {
				header('location: index.php');
			}
			exit();
		} else {
			$emails = $user_login;
			$error_message = '<br><br>
				<div class="maincontent_text" style="text-align: center; font-size: 18px;">
				<font face="bookman">Code not matched!<br>
				</font></div>';
		}
	} else {
		$error_message = '<br><br>
				<div class="maincontent_text" style="text-align: center; font-size: 18px;">
				<font face="bookman">Activation code not matched!<br>
				</font></div>';
	}
}

?>

<!doctype html>
<html>

<head>
	<title>Welcome FakeSportsGear</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body class="home-welcome-text">
	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav">
				<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>
			</ul>
		</div>
	</nav>

	<main class="form-signin  m-auto">
		<div class="container">
			<div class="row justify-content-center mt-5">
				<div class="col-md-6">
					<?php
					if (isset($activacc)) {
						echo '<h2>Activation Form</h2>';
					} else {
						echo '<h2>FSG Login Form</h2>';
					}
					?>


					<form action="" method="POST" class="registration">

						<?php
						if (isset($activacc)) {

							echo '
													<div class="signup_error_msg">
														<div class="maincontent_text" style="text-align: center; font-size: 18px;">
													<font face="bookman">Check your email!<br>
													</font></div>
													</div>
													<div>
														<td>
															<input name="acemail" placeholder="Enter Your Email" required="required" class="email signupbox" type="email" size="30" value="' . $emails . '">
														</td>
													</div>
													<div>
														<td>
															<input name="actcode" placeholder="Activation Code" required="required" class="email signupbox" type="text" size="30" value="' . $acccode . '">
														</td>
													</div>
													<div>
														<input name="activate" class="uisignupbutton signupbutton" type="submit" value="Active Account">
													</div>
													';
						} else {
							echo '
							<div class="mb-3">
											<td>
												<input name="email" placeholder="Enter Your Email" required="required" class="form-control" type="email" size="30" value="' . $emails . '">
											</td>
										</div>
										<div>
											<td>
												<input name="password" id="password-1" required="required"  placeholder="Enter Password"class="form-control" type="password" size="30" value="' . $passs . '">
											</td>
										</div>
										<div>
											<input name="login" class="btn btn-primary" type="submit" value="Log In">
										</div>
										';
						}
						?>

						<div class="signup_error_msg">
							<?php
							if (isset($error_message)) {
								echo $error_message;
							}

							?>
						</div>

					</form>

				</div>
			</div>
		</div>

	</main>
	<footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
		<div class="container">
			<span>
				<h3 class="">Disclaimer</h3>
				<p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
			</span>
		</div>
	</footer>

	<script src="movement.js" charset="utf-8"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>