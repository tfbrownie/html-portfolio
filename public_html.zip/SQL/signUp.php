<?php
include("../inclu/Check_connection.php");




ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
} else {
	header("location: index.php");
}

$u_fname = "";
$u_lname = "";
$u_email = "";
$u_mobile = "";
$u_address = "";
$u_pass = "";

if (isset($_POST['signup'])) {
	//declere veriable
	$u_fname = $_POST['first_name'];
	$u_lname = $_POST['last_name'];
	$u_email = $_POST['email'];
	$u_mobile = $_POST['mobile'];
	$u_address = $_POST['signupaddress'];
	$u_pass = $_POST['password'];
	//triming name
	$_POST['first_name'] = trim($_POST['first_name']);
	$_POST['last_name'] = trim($_POST['last_name']);
	try {

		if (empty($_POST['first_name'])) {
			throw new Exception('Fullname can not be empty');
		}
		if (is_numeric($_POST['first_name'][0])) {
			throw new Exception('Please write your correct name!');
		}
		if (empty($_POST['last_name'])) {
			throw new Exception('Lastname can not be empty');
		}
		if (is_numeric($_POST['last_name'][0])) {
			throw new Exception('lastname first character must be a letter!');
		}
		if (empty($_POST['email'])) {
			throw new Exception('Email can not be empty');
		}
		if (empty($_POST['mobile'])) {
			throw new Exception('Mobile can not be empty');
		}
		if (empty($_POST['password'])) {
			throw new Exception('Password can not be empty');
		}
		if (empty($_POST['signupaddress'])) {
			throw new Exception('Address can not be empty');
		}


		// Check if email already exists

		$check = 0;
		$e_check = mysqli_query($db, "SELECT email FROM `user` WHERE email='$u_email'");
		$email_check = mysqli_num_rows($e_check);
		if (strlen($_POST['first_name']) > 2 && strlen($_POST['first_name']) < 20) {
			if (strlen($_POST['last_name']) > 2 && strlen($_POST['last_name']) < 20) {
				if ($check == 0) {
					if ($email_check == 0) {
						if (strlen($_POST['password']) > 1) {
							$d = date("Y-m-d"); //Year - Month - Day
							$_POST['first_name'] = ucwords($_POST['first_name']);
							$_POST['last_name'] = ucwords($_POST['last_name']);
							$_POST['last_name'] = ucwords($_POST['last_name']);
							$_POST['email'] = mb_convert_case($u_email, MB_CASE_LOWER, "UTF-8");
							$_POST['password'] = md5($_POST['password']);
							$confirmCode   = substr(rand() * 900000 + 100000, 0, 6);
							$result = mysqli_query($db, "INSERT INTO user (firstName,lastName,email,mobile,address,password,confirmCode,activation) VALUES ('$_POST[first_name]','$_POST[last_name]','$_POST[email]','$_POST[mobile]','$_POST[signupaddress]','$_POST[password]','$confirmCode', 'yes')");
							// send email
							/*$msg = "
						...
						
						Your activation code: ".$confirmCode."
						Signup email: ".$_POST['email']."
						
						";
						if (@mail($_POST['email'],"FakeSportsGear Activation Code",$msg, "From:FakeSportsGear <no-reply@FakeSportsGear.com>")) {
							
						
						
						//success message
						*/
							$success_message = '
					<div class="modal-dialog p-4 py-md-25" role="document">
						<div class="modal-content rounded-4 shadow">
						<div class="modal-header border-bottom-0">
							<h1 class="modal-title fs-5">Signup Successful</h1>
						</div>
						<div class="modal-body py-0">
							<p>You can now experience what we have to offer</p>
						<p>Your activation code: ' . $confirmCode . '</p>
						</div>
						<div class="modal-footer flex-column align-items-stretch w-100 gap-2 pb-3 border-top-0">
							<a href="../SQL/logIn.php"><button type="button" class="btn btn-lg btn-primary">Log In Here</button></a>
							
						</div>
						</div>
					</div>';
							/*}else {
							throw new Exception('Email is not valid!');
						}*/
						} else {
							throw new Exception('Make a stronger password');
						}
					} else {
						throw new Exception('Email already taken, please use a different email address.');
					}
				} else {
					throw new Exception('Username already taken, please use a different username.');
				}
			} else {
				throw new Exception('Lastname must be 2-20 characters!');
			}
		} else {
			throw new Exception('Firstname must be 2-20 characters!');
		}
	} catch (Exception $e) {
		$error_message = $e->getMessage();
	}
}


?>


<!doctype html>
<html>

<head>
	<title>Fake Sports Merch Marketplace</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body class="home-welcome-text">

	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav">
				<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>
			</ul>
		</div>
	</nav>
	<?php
	if (isset($success_message)) {
		echo $success_message;
	} else {
		echo '
					
						<div class="container">
							<div class="row justify-content-center mt-5">
								
									<div class="col-md-6">
										
										
										
										<h2>Register Here</h2>
											<form action="" method="POST" class="registration">
											
												
											<div class="mb-3">
														<td >
															<input name="first_name" id="first_name" placeholder="First Name" required="required" class="form-control" type="text" size="30" value="' . $u_fname . '" >
														</td>
													</div>
													<div class="mb-3">
														<td >
															<input name="last_name" id="last_name" placeholder="Last Name" required="required" class="form-control" type="text" size="30" value="' . $u_lname . '" >
														</td>
													</div>
													<div class="mb-3">
														<td>
															<input name="email" placeholder="Enter Your Email" required="required" class="form-control" type="email" size="30" value="' . $u_email . '">
														</td>										
													</div>
													<div class="mb-3">
														<td>
															<input name="mobile" placeholder="Enter Your Mobile" required="required" class="form-control" type="text" size="30" value="' . $u_mobile . '">
														</td>
													</div>
													<div class="mb-3">
														<td>
															<input name="signupaddress" placeholder="Write Your Full Address" required="required" class="form-control" type="text" size="30" value="' . $u_address . '">
														</td>
													</div>
													<div class="mb-3">
														<td>
															<input name="password" id="password-1" required="required"  placeholder="Enter New Password" class="form-control" type="password" size="30" value="' . $u_pass . '">
														</td>
													</div>
													<div class="mb-3">
														<input name="signup" class="btn btn-primary" type="submit" value="Sign Me Up!">
													</div>
													<div class="signup_error_msg">';

		if (isset($error_message)) {
			echo $error_message;
		}


		echo '</div>
												
											</form>
											
										
									</div>
								
							</div>
						</div>
					
				';
	}

	?>
	<footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
		<div class="container">
			<span>
				<h3 class="">Disclaimer</h3>
				<p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
			</span>
		</div>
	</footer>

	<script src="movement.js" charset="utf-8"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>