<?php
include("../inclu/Check_connection.php");


ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
    $user = "";
} else {
    $user = $_SESSION['user_login'];
    $result = $mysqli->query("SELECT * FROM user WHERE email='$user'");
    $get_user_email = mysqli_fetch_assoc($result);
    $uname_db = $get_user_email['firstName'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fake Sports Gear</title>
    <link href="styles.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <?php
    include("../inclu/Check_connection.php");
    ?>


</head>

<body>
    <nav class="py-2 bg-body-tertiary border-bottom">
        <div class="container d-flex flex-wrap">
            <ul class="nav me-auto">
                <li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
                <li class="nav-item"><a href="./Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
                <li class="nav-item"><a href="#" class="nav-link link-body-emphasis px-2 fw-bolder">About</a></li>
            </ul>

            <ul class="nav">
                <?php

                if ($user != "") {
                    echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
                    echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
                } else {
                    echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
                    echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
                }
                ?>
            </ul>
        </div>
    </nav>
    <div class="p-5 mb-4 bg-body-tertiary rounded-3">
        <div class="container-fluid py-5">
            <h1 class="display-5 fw-bold">About the Creator</h1>
            <p class="col-md-8 fs-4">Hello, my name is Thomas Brown I created this website as a demonstrate my skills as a web developer</p>
        </div>
    </div>


    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column text-center">
        <main class="px-3">
            <h1>Why I created FSG</h1>
            <p class="lead">The purpose of this website is a project for me to showcase my skills as a learning web developer. PHP, MySQL, HTML and Bootstrap are the main tools I used for this project. In my other projects, I have also had to use vanilla Javascript and CSS, and Jquery for web pages like this <a href="Drumbkit"> drum kit </a> and this <a href="Simon Game">Simon Game</a>. I hope you enjoy the site and feel free to reach out with any comments or suggestions!</p>

        </main>
    </div>


    <footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
        <div class="container">
            <span>
                <h3 class="">Disclaimer</h3>
                <p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
            </span>
        </div>
    </footer>

    <script src="movement.js" charset="utf-8"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>