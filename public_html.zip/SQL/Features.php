<?php
include("../inclu/Check_connection.php");


ob_start();
session_start();
if (!isset($_SESSION['user_login'])) {
    $user = "";
} else {
    $user = $_SESSION['user_login'];
    $result = $mysqli->query("SELECT * FROM user WHERE email='$user'");
    $get_user_email = mysqli_fetch_assoc($result);
    $uname_db = $get_user_email['firstName'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fake Sports Gear</title>
    <link href="styles.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <?php
    include("../inclu/Check_connection.php");
    ?>


</head>

<body>
    <nav class="py-2 bg-body-tertiary border-bottom">
        <div class="container d-flex flex-wrap">
            <ul class="nav me-auto">
                <li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
                <li class="nav-item"><a href="./Features.php" class="nav-link link-body-emphasis px-2 fw-bolder">Features</a></li>
                <li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
            </ul>

            <ul class="nav">
                <?php

                if ($user != "") {
                    echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
                    echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
                } else {
                    echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
                    echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
                }
                ?>
            </ul>
        </div>
    </nav>
    <div class="p-5 mb-4 bg-body-tertiary rounded-3">
        <div class="container-fluid py-5">
            <h1 class="display-5 fw-bold">Fake Sports Gear Marketplace</h1>
            <p class="col-md-8 fs-4">Welome to the primary marketplace for all your counterfeit sports gear needs.</p>
        </div>
    </div>




    <hr class="featurette-divider">

    <div class="row featurette">
        <div class="col-md-7">
            <h2 class="featurette-heading fw-normal lh-1">Become a customer and experience what we have to offer! <span class="text-body-secondary">It’ll blow your mind.</span></h2>
            <p class="lead">This is the perfect place to buy cheap sports gear!</p>
        </div>
        <div class="col-md-5">
            <img src="../Images/Product Images/AJBROWNJERSEY.jpg" width="500" height="500">
        </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
        <div class="col-md-7 order-md-2">
            <h2 class="featurette-heading fw-normal lh-1">Order Products with Ease</h2>
            <p class="lead">After you find the perfect product, the seamless ordering process has customers receivng product in record time!</p>
        </div>
        <div class="col-md-5 order-md-1">
            <img src="../Images/Website Images/Ordering History.png" width="900" height="500">
        </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
        <div class="col-md-7">
            <h2 class="featurette-heading fw-normal lh-1">Admin Capabilities are Almost Endless </h2>
            <p class="lead">Admins can list products, edit orders, edit products and view their sales History</p>
        </div>
        <div class="col-md-5">
            <img src="../Images/Website Images/Sales History.png" width="900" height="500">
        </div>
    </div>

    <hr class="featurette-divider">

    <?php include("../inclu/footer.php") ?>