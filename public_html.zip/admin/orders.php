<?php include("../inclu/Check_connection.php"); ?>
<?php
ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
	header("location: adminLogin.php");
	$user = "";
} else {
	$user = $_SESSION['admin_login'];
	$result = mysqli_query($db, "SELECT * FROM admin WHERE id='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
}

?>


<!doctype html>
<html>

<head>
	<title>FSG Orders</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>



<body>
	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav me-auto">
				<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
				<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
				<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
			</ul>

			<ul class="nav">
				<?php

				if ($user != "") {
					echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
					echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
				} else {
					echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
					echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
				}
				?>
			</ul>
		</div>
		<hr>
		<? include("../inclu/menuHeader.php"); ?>
	</nav>
	<div class="px-4 py-5 my-5 mb-5 text-center">
		<h1 class="display-5 fw-bold text-body-emphasis">Sales History</h1>
	</div>
	</div>
	<div>
		<table class="table">
			<thead>
				<tr style="font-weight: bold;" colspan="10">
					<th>Order Id</th>
					<th>User Id</th>
					<th>Product Id</th>
					<th>Q*P= Revenue</th>
					<th>Order Place</th>
					<th>Mobile</th>
					<!-- <th>Order Status</th> -->
					<th>Order Date</th>
					<th>Delevery Date</th>
					<th>User Name</th>
					<th>User Mobile</th>
					<th>User Email</th>
					<th>Image <br> Click to Edit</th>
				</tr>
			</thead>
			<tr>
				<?php
				$query = "SELECT * FROM orders ORDER BY id DESC";
				$run = mysqli_query($db, $query);
				while ($row = mysqli_fetch_assoc($run)) {
					$oid = $row['id'];
					$ouid = $row['uid'];
					$opid = $row['pid'];
					$oquantity = $row['quantity'];
					$oplace = $row['oplace'];
					$omobile = $row['mobile'];
					// $odstatus = $row['dstatus'];
					$odate = $row['odate'];
					$ddate = $row['ddate'];
					//getting user info
					$query1 = "SELECT * FROM user WHERE id='$ouid'";
					$run1 = mysqli_query($db, $query1);
					$row1 = mysqli_fetch_assoc($run1);
					$ofname = $row1['firstName'];
					$oumobile = $row1['mobile'];
					$ouemail = $row1['email'];

					//product info
					$query2 = "SELECT * FROM products WHERE id='$opid'";
					$run2 = mysqli_query($db, $query2);
					$row2 = mysqli_fetch_assoc($run2);
					$opcate = $row2['category'];
					$opname = $row2['pName'];
					$oppicture = $row2['picture'];
					$oprice = $row2['price'];


				?>
					<th><?php echo $oid; ?></th>
					<th><?php echo $ouid; ?></th>
					<th><?php echo $opid; ?></th>
					<th><?php echo '' . $oquantity . ' * ' . $oprice . ' = $ ' . $oquantity * $oprice . ''; ?></th>
					<th><?php echo $oplace; ?></th>
					<th><?php echo $omobile; ?></th>
					<!-- <th><?php echo $odstatus; ?></th> -->
					<th><?php echo $odate; ?></th>
					<th><?php echo $ddate; ?></th>

					<th><?php echo $ofname; ?></th>
					<th><?php echo $oumobile; ?></th>
					<th><?php echo $ouemail; ?></th>
					<th><?php echo '<div class="home-prodlist-img"><a href="editorder.php?eoid=' . $oid . '">
									<img src="../images/Product Images/' . $oppicture . '" class="home-prodlist-imgi" style="height: 75px; width: 75px;">
									</a>
								</div>' ?></th>
			</tr>
		<?php } ?>
		</table>
	</div>
	<? include("../inclu/footer.php"); ?>