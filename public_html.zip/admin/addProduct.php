<?php
include("../inclu/Check_connection.php");
?>
<?php
ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
	header("location: login.php");
	$user = "";
} else {
	$user = $_SESSION['admin_login'];
	$result = $mysqli->query("SELECT * FROM admin WHERE id='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
}
$pName = "";
$price = "";
$available = "";
$category = "";
$type = "";
$size = "";
$pCode = "";
$descri = "";

if (isset($_POST['signup'])) {
	//declere veriable
	$pname = $_POST['pName'];
	$price = $_POST['price'];
	$available = $_POST['available'];
	$category = $_POST['category'];
	$type = $_POST['type'];
	$size = $_POST['size'];
	$pCode = $_POST['code'];
	$descri = $_POST['descri'];
	//triming name
	$_POST['pName'] = trim($_POST['pName']);

	//finding file extention
	$profile_pic_name = @$_FILES['profilepic']['name'];
	$file_basename = substr($profile_pic_name, 0, strripos($profile_pic_name, '.'));
	$file_ext = substr($profile_pic_name, strripos($profile_pic_name, '.'));

	if (((@$_FILES['profilepic']['type'] == 'image/jpeg') || (@$_FILES['profilepic']['type'] == 'image/png') || (@$_FILES['profilepic']['type'] == 'image/gif')) && (@$_FILES['profilepic']['size'] < 1000000)) {

		$pName = $pName;
		if (file_exists("../images/Product Images/$pName")) {
			//nothing
		} else {
			mkdir("../images/Product Images/$pName");
		}


		$filename = strtotime(date('M-D-Y H:i:s')) . $file_ext;

		if (file_exists("../images/Product Images/$pName/" . $filename)) {
			echo @$_FILES["profilepic"]["name"] . "Already exists";
		} else {
			if (move_uploaded_file(@$_FILES["profilepic"]["tmp_name"], "../images/Product Images/$pName/" . $filename)) {
				$photos = $filename;
				$result = mysqli_query($db, "INSERT INTO products(pName,price,description,available,category,type,size,pCode,picture) VALUES ('$_POST[pName]','$_POST[price]','$_POST[descri]','$_POST[available]','$_POST[category]','$_POST[type]','$_POST[size]','$_POST[code]','$photos')");

				header("Location: ../Products/allProducts.php");
			} else {
				echo "Upload Error";
			}
			//echo "Uploaded and stored in: userdata/profile_pics/$item/".@$_FILES["profilepic"]["name"];


		}
	} else {
		$error_message = 'Add picture!';
	}
}
$search_value = "";

?>


<!doctype html>
<html>

<head>
	<title>FSG Add Product</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>

<body class>

	<head>
		<title>Admin Home</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="styles.css" rel="stylesheet">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	</head>

	<body>
		<nav class="py-2 bg-body-tertiary border-bottom">
			<div class="container d-flex flex-wrap">
				<ul class="nav me-auto">
					<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
					<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
					<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
				</ul>

				<ul class="nav">
					<?php

					if ($user != "") {
						echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
						echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
					} else {
						echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
						echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
					}
					?>
				</ul>
			</div>
			<hr>
			<? include("../inclu/menuHeader.php"); ?>
		</nav>
		<div class="row">

			<?php
			if (isset($success_message)) {
				echo $success_message;
			} else {
				echo '
					<div class="holecontainer d-flex pb-5 align-items-center justify-content-center">
						<div>
							<div>
								<div>
									<div class="container py-5  align-items-center justify-content-center">
										<h2 class =" align-items-centerr">Add a Product</h2>
										<div class="signup_error_msg">';
				if (isset($error_message)) {
					echo $error_message;
				}
				echo '</div>
										<div class="signupform_text"></div>
										<div class="contianer">
											<form action="" method="POST" class="registration" enctype="multipart/form-data">
												<div class="form-group mb-3">												
												<input name="pName" id="first_name" placeholder="Product Name" required="required" class="form-control" type="text" size="30" value="' . $pName . '" >
												</div>									
												<div class="form-group mb-3">
												<input name="price" id="last_name" placeholder="Price" required="required" class="form-control" type="text" size="30" value="' . $price . '" >
												</div>
												<div class="form-group mb-3">												
												<input name="available" placeholder="Available Quantity" required="required" class="form-control" type="text" size="30" value="' . $available . '">
												</div>
												<div class="form-group mb-3">
												<input name="descri" id="first_name" placeholder="Description" required="required" class="form-control" type="text" size="30" value="' . $descri . '" >
												</div>
												<div class="form-group mb-3">
												<input name="size" id="first_name" placeholder="Size" required="required" class="form-control" type="text" size="30" value="' . $size . '" >
												</div>												
												<div class="form-group mb-3">
														<td>
															<select name="category" required="required"  class="form-select form-select-lg mb-3">
																<option selected value="Jersey">Jersey</option>
																<option value="shoes">Shoes</option>
																<option value="hats">Hats</option>
																<option value="tshirt">T-Shirt</option>																
															</select>
														</td>
													</div>
													<div class="form-group mb-3">
													<td>
														<select name="type" required="required"  class="form-select form-select-lg mb-3">
															<option selected value="mens">Mens</option>
															<option selected value="womens">Womens</option>
															<option selected value="Unisex">Unisex</option>																														
														</select>
													</td>
												</div>
												<div class="form-group mb-3">
														
															<input name="code" id="password-1" required="required"  placeholder="Code" class="form-control" type="text" size="30" value="' . $pCode . '">
														
													</div>
													<div class = "form-group mb-3">
														
															<input name="profilepic" class="form-control"  type="file" value="Add Pic">
														
													</div>
													<div class = "form-group mb-3">
														<input name="signup" class="btn btn-primary" type="submit" value="Add Product">
													</div>
												</div>
											</form>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				';
			}

			?>
		</div>

		<footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
			<div class="container">
				<span>
					<h3 class="">Disclaimer</h3>
					<p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
				</span>
			</div>
		</footer>

		<script src="movement.js" charset="utf-8"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	</body>

</html>