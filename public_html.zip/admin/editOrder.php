<?php include("../inclu/Check_connection.php"); ?>
<?php

ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
	$user = "";
	header("location: login.php?ono=" . $eoid . "");
} else {
	if (isset($_REQUEST['eoid'])) {

		$eoid = mysqli_real_escape_string($db, $_REQUEST['eoid']);
		$getposts5 = mysqli_query($db, "SELECT * FROM orders WHERE id='$eoid'") or die(mysqli_error());
		if (mysqli_num_rows($getposts5)) {
		} else {
			header('location: AdminIndex.php');
		}
	} else {
		header('location: AdminIndex.php');
	}
	$user = $_SESSION['admin_login'];
	$result = mysqli_query($db, "SELECT * FROM admin WHERE id='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];


	$result1 = mysqli_query($db, "SELECT * FROM orders WHERE id='$eoid'");
	$get_order_info = mysqli_fetch_assoc($result1);
	$eouid = $get_order_info['uid'];
	$eopid = $get_order_info['pid'];
	$eoquantity = $get_order_info['quantity'];
	$eoplace = $get_order_info['oplace'];
	$eomobile = $get_order_info['mobile'];
	$eodstatus = $get_order_info['dstatus'];
	$eodustatus = ucwords($get_order_info['dstatus']);
	$eodate = $get_order_info['odate'];
	$eddate = $get_order_info['ddate'];

	$result2 = mysqli_query($db, "SELECT * FROM user WHERE id='$eouid'");
	$get_order_info2 = mysqli_fetch_assoc($result2);
	$euname = $get_order_info2['firstName'];
	$euemail = $get_order_info2['email'];
	$eumobile = $get_order_info2['mobile'];
}

$getposts = mysqli_query($db, "SELECT * FROM products WHERE id ='$eopid'") or die(mysqli_error());
if (mysqli_num_rows($getposts)) {
	$row = mysqli_fetch_assoc($getposts);
	$id = $row['id'];
	$pName = $row['pName'];
	$price = $row['price'];
	$description = $row['description'];
	$picture = $row['picture'];
	$size = $row['size'];
	$category = $row['category'];
	$available = $row['available'];
}

//order

if (isset($_POST['order'])) {
	//declere veriable
	$eodstatus = $_POST['dstatus'];
	$dquantity = $_POST['quantity'];
	$ddate = $_POST['ddate'];
	//triming name
	try {
		if (empty($_POST['dstatus'])) {
			throw new Exception('Status can not be empty');
		}
		if (mysqli_query($db, "UPDATE orders SET dstatus='$eodstatus', ddate='$ddate', quantity='$dquantity' WHERE id='$eoid'")) {
			//success message
			//header('location: editorder.php?eoid=' . $eoid . '');
			$success_message = '
				<div class="signupform_content"><h2><font face="bookman">Change successfull!</font></h2>
				</div>';
		}
	} catch (Exception $e) {
		$error_message = $e->getMessage();
	}
}
if (isset($_POST['delorder'])) {
	//triming name
	if (mysqli_query($db, "DELETE FROM orders WHERE id='$eoid'")) {

		header('location: orders.php');
	}
}
$search_value = "";


?>

<!DOCTYPE html>
<html>

<head>
	<title>FSG Edit Order</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>


<body>
	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav me-auto">
				<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
				<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
				<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
			</ul>

			<ul class="nav">
				<?php

				if ($user != "") {
					echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
					echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
				} else {
					echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
					echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
				}
				?>
			</ul>
		</div>
	</nav>
	<div class="px-4 py-5 my-5 mb-5 text-center">
		<h1 class="display-5 fw-bold text-body-emphasis">Edit Order</h1>
	</div>
	<div class="row " style=" padding-top: 20px; padding: 0 20%">
		<main>
			<div class="container d-flex justify-content-center align-items-center ">
				<div>

					<div>
						<?php
						echo '
						
						<div >
							<form action="" method="POST" class="registration">
								<div class="signup_form" >
									<div class="form-group mb-3">
										<td>
											<input name="ddate" placeholder="Delevary date" required="required" class="form-control" type="date" size="30" value="' . $eddate . '">
										</td>
									</div>
									<div>
										<td>
										<label for="dstatus" class="form-label">Edit Delivery Status</label>
											<select name="dstatus" required="required"  class="form-select form-select-lg mb-3">
														<option selected value="' . $eodstatus . '">' . $eodustatus . '</option>
														<option value="Not Yet">Not Yet</option>
														<option value="Yes">Yes</option>
														<option value="Cancel">Cancel</option>
													</select>
										</td>
									</div>
									<div>
										<td>
										<label for="quantity" class="form-label">Edit Quantity</label>
											<select name="quantity" required="required" class="form-select form-select-lg mb-3">
										<option selected value="' . $eoquantity . '">Quantity: ' . $eoquantity . '</option>';
						?><?php
							for ($i = 1; $i <= $available; $i++) {
								echo '<option value="' . $i . '">Quantity: ' . $i . '</option>';
							}
							?>
						<?php echo '
											</select>
										</td>
									</div>
									<div class = "mb-3">
										<input name="order" class="btn btn-primary" type="submit" value="Confirm Change">
									</div>
									<div>
										<input name="delorder"  class="btn btn-primary" type="submit" value="Delete Order">
									</div>
									<div class="signup_error_msg"> '; ?>
						<?php
						if (isset($error_message)) {
							echo $error_message;
						}

						?>
						<?php echo '</div>
								</div>
							</form>
							
						</div>
					

					';
						if (isset($success_message)) {
							echo $success_message;
						}

						?>

					</div>
				</div>

				<div style=" float: left;">
					<div>
						<?php
						echo '
					<div class="col-md-6 col-lg-6 order-md-last">
						<ul style="float: left; list-style:none">
							<li style="float: left; padding: 0px 25px 25px 25px;">
							<div class="card shadow-sm">
									<img src="../Images/Product Images/' . $picture . '" class="home-prodlist-imgi"  style="width:500px;height:600px;">
									
									<div style="text-align: center; padding: 0 0 6px 0;">' . $pName . '</div>
								</div>
								
							</li>
						</ul>
						</div>
					';
						?>
					</div>
				</div>
			</div>
		</main>
	</div>
	<footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
		<div class="container">
			<span>
				<h3 class="">Disclaimer</h3>
				<p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
			</span>
		</div>
	</footer>

	<script src="movement.js" charset="utf-8"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>