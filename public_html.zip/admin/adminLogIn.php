<?php include("../inclu/Check_connection.php"); ?>

<?php
ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
} else {
	//header("location: index.php");
}

if (isset($_POST['login'])) {
	if (isset($_POST['email']) && isset($_POST['password'])) {
		$user_login = mysqli_real_escape_string($db, $_POST['email']);
		$user_login = mb_convert_case($user_login, MB_CASE_LOWER, "UTF-8");
		$password_login = mysqli_real_escape_string($db, $_POST['password']);
		$num = 0;
		//$password_login_md5 = md5($password_login);
		$result = mysqli_query($db, "SELECT * FROM admin WHERE (email='$user_login') AND password='$password_login'");
		$num = mysqli_num_rows($result);
		$get_user_email = mysqli_fetch_assoc($result);
		$get_user_uname_db = $get_user_email['id'];
		if ($num > 0) {
			$_SESSION['admin_login'] = $get_user_uname_db;
			setcookie('admin_login', $user_login, time() + (365 * 24 * 60 * 60), "/");
			header('location: Adminindex.php');
			exit();
		} else {
			$error_message = '<br><br>
				<div class="maincontent_text" style="text-align: center; font-size: 18px;">
				<font face="bookman">Username or Password incorrect.<br>
				</font></div>';
		}
	}
}

$search_value = "";

?>

<!doctype html>
<html>

<head>
	<title>FSG Admin Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="styles.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body class="home-welcome-text">
	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav me-auto">
				<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
				<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
				<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
			</ul>
			<ul class="nav">
				<!-- <?php
						if ($user != "") {
							echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
							echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
						} else {
							echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
							echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
						}
						?> -->
			</ul>
		</div>
	</nav>

	<? include("../inclu/menuHeader.php"); ?>
	<div class="d-flex align-items-center py-4 bg-body-tertiary">
		<main class="form-signin m-auto">
			<form action="" method="POST" class="registration">
				<h1 class="h3 mb-3 fw-normal">Admin Log In</h1>
				<div class="form-floating">
					<td>
						<input name="email" placeholder="Enter Your Email" required="required" class="form-control" type="email" size="30">
					</td>
				</div>
				<div class="form-floating">
					<td>
						<input name="password" id="password-1" required="required" placeholder="Enter Password" class="form-control" type="password" size="30">
					</td>
				</div>
				<button name="login" class="btn btn-primary w-100 py-2" type="submit">Sign in</button>
				<div class="signup_error_msg">
					<?php
					if (isset($error_message)) {
						echo $error_message;
					}

					?>
				</div>
			</form>
		</main>
	</div>

	<footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
		<div class="container">
			<span>
				<h3 class="">Disclaimer</h3>
				<p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
			</span>
		</div>
	</footer>

	<script src="movement.js" charset="utf-8"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>