<?php include("../inclu/Check_connection.php"); ?>
<?php
ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
  header("location: login.php");
  $user = "";
} else {
  $user = $_SESSION['admin_login'];
  $result = $mysqli->query("SELECT * FROM admin WHERE id='$user'");
  $get_user_email = mysqli_fetch_assoc($result);
  $uname_db = $get_user_email['firstName'];
}

$search_value = "";
?>
<!DOCTYPE html>
<html>

<head>
  <title>Admin Home</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="styles.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
  <nav class="py-2 bg-body-tertiary border-bottom">
    <div class="container d-flex flex-wrap">
      <ul class="nav me-auto">
        <li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
        <li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
        <li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
      </ul>

      <ul class="nav">
        <?php

        if ($user != "") {
          echo '<li class="nav-item"><a href="../SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
          echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
        } else {
          echo '<li class="nav-item"><a href="../SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
          echo '<li class="nav-item"><a href="../SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
        }
        ?>
      </ul>
    </div>
  </nav>
  <div class="px-2 py-2 my-1 text-center">

    <h1 class="display-5 fw-bold text-body-emphasis">Admin Home</h1>

  </div>
  <div class="row d-flex flex-column flex-md-row p-4 gap-4 py-md-5 align-items-center justify-content-center">
    <div class="album py-5 bg-body-tertiary">
      <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

          <div class="col">
            <div class="card shadow-sm">
              <img src="../Images/Website Images/addProduct.jpg" class="rounded float-start" alt="Administrator">
              <div class="card-body">
                <h3>Add Product</h3>
                <p class="card-text">Place a Product for Sale on the Marketplace</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="addproduct.php">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Add Product</button>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img src="../Images/Website Images/open box.jpg" class="rounded float-start" alt="open box">
              <div class="card-body">
                <h3>Sales History</h3>
                <p class="card-text">View the Sales of your Products & Edit Orders</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="orders.php"> <button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img src="../Images/Website Images/adminstrator.jpg" class="rounded float-start" alt="Reggie White Jersey">
              <div class="card-body">
                <h3>Add Admin</h3>
                <p class="card-text">Add a new Administrator</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="newadmin.php"><button type="button" class="btn btn-sm btn-outline-secondary">Add Admin</button></a>
                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <img src="../Images/Website Images/editor.jpg" class="rounded float-start" alt="Administrator">
              <div class="card-body">
                <h3>Edit Product</h3>
                <p class="card-text">Edit a Product on the Marketplace</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="allProducts.php">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Pick A Product to Edit</button>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

  </div>
  <?php
  include("../inclu/footer.php");
  ?>