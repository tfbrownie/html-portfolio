<?php include("../inclu/Check_connection.php"); ?>
<?php
ob_start();
session_start();
if (!isset($_SESSION['admin_login'])) {
	header("location: AdminLogin.php");
	$user = "";
} else {
	$user = $_SESSION['admin_login'];
	$result = mysqli_query($db, "SELECT * FROM admin WHERE  id='$user'");
	$get_user_email = mysqli_fetch_assoc($result);
	$uname_db = $get_user_email['firstName'];
}
if (isset($_POST['signup'])) {
	//declere veriable
	$u_fname = $_POST['first_name'];
	$u_lname = $_POST['last_name'];
	$u_email = $_POST['email'];
	$u_mobile = $_POST['mobile'];
	$u_address = $_POST['signupaddress'];
	//triming name
	$_POST['first_name'] = trim($_POST['first_name']);
	$_POST['last_name'] = trim($_POST['last_name']);
	try {
		if (empty($_POST['first_name'])) {
			throw new Exception('Fullname can not be empty');
		}
		if (is_numeric($_POST['first_name'][0])) {
			throw new Exception('Please write your correct name!');
		}
		if (empty($_POST['last_name'])) {
			throw new Exception('Lastname can not be empty');
		}
		if (is_numeric($_POST['last_name'][0])) {
			throw new Exception('lastname first character must be a letter!');
		}
		if (empty($_POST['email'])) {
			throw new Exception('Email can not be empty');
		}
		if (empty($_POST['mobile'])) {
			throw new Exception('Mobile can not be empty');
		}
		if (empty($_POST['password'])) {
			throw new Exception('Password can not be empty');
		}
		// if(empty($_POST['admintype'])) {
		// 	throw new Exception('Admin Type can not be empty');
		// }
		if (empty($_POST['signupaddress'])) {
			throw new Exception('Address can not be empty');
		}
		// Check if email already exists
		$check = 0;
		$e_check = mysqli_query($db, "SELECT email FROM `admin` WHERE email='$u_email'");
		$email_check = mysqli_num_rows($e_check);
		if (strlen($_POST['first_name']) > 2 && strlen($_POST['first_name']) < 16) {
			if ($check == 0) {
				if ($email_check == 0) {
					if (strlen($_POST['password']) > 4) {
						$d = date("M-d-Y");
						$_POST['first_name'] = ucwords($_POST['first_name']);
						$_POST['last_name'] = ucwords($_POST['last_name']);
						$_POST['password'] = md5($_POST['password']);
						$confirmCode   = substr(rand() * 900000 + 100000, 0, 6);
						// send email
						$msg = "
					Hello!
						Your activation code: " . $confirmCode . "
						Signup email: " . $_POST['email'] . "
						";
						$result = mysqli_query($db, "INSERT INTO admin (firstName,lastName,email,mobile,address,password,type,confirmCode) VALUES ('$_POST[first_name]','$_POST[last_name]','$_POST[email]','$_POST[mobile]','$_POST[signupaddress]','$_POST[password]','$_POST[admintype]','$confirmCode')");
						//success message
						$success_message = '
						<div class="signupform_content"><h2><font face="bookman">Admin Registration Successfull!</font></h2>
						<div class="signupform_text" style="font-size: 18px; text-align: center;">
						<font face="bookman">
							Email: ' . $u_email . '<br>
							Account Successfully Created. <br>
							<p>They can now log on as an Admin</p>
						</font></div></div>';
					} else {
						throw new Exception('Password must be 5 or more then 5 characters!');
					}
				} else {
					throw new Exception('Email already taken!');
				}
			} else {
				throw new Exception('Username already taken!');
			}
		} else {
			throw new Exception('Firstname must be 2-15 characters!');
		}
	} catch (Exception $e) {
		$error_message = $e->getMessage();
	}
}
$search_value = "";
?>
<!doctype html>
<html>

<head>
	<title>FSG Admin Signup</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="styles.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body class="home-welcome-text" style="">
	<nav class="py-2 bg-body-tertiary border-bottom">
		<div class="container d-flex flex-wrap">
			<ul class="nav me-auto">
				<li class="nav-item"><a href="../SQL/index.php" class="nav-link link-body-emphasis px-2 active" aria-current="page">Home</a></li>
				<li class="nav-item"><a href="../SQL/Features.php" class="nav-link link-body-emphasis px-2">Features</a></li>
				<li class="nav-item"><a href="../SQL/about.php" class="nav-link link-body-emphasis px-2">About</a></li>
			</ul>
			<ul class="nav">
				<?php
				if ($user != "") {
					echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logout.php" class="nav-link link-body-emphasis px-2">Log Out</a></li>';
					echo '<li class="nav-item body-emphasis my-2 px-4">Hello ' . $uname_db . '!</li>';
				} else {
					echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>';
					echo '<li class="nav-item"><a href="http://localhost/PHP%20Test%20Site/SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>';
				}
				?>
			</ul>
		</div>
	</nav>

	<? include("../inclu/menuHeader.php"); ?>
	<div class="container py-5 d-flex align-items-center justify-content-center ">
		<?

		if (isset($success_message)) {
			echo $success_message;
		} else {
			echo '
				<div class = "">
					<div class="">
						<main class="form-signin w-100 m-auto">						
								<form action="" method="POST" class="registration">
									<h2>New Admin Form</h2>												
									<div class="form-group mb-3">
										<td >
											<input name="first_name" id="first_name" placeholder="First Name" required="required" class="form-control" type="text" size="30" value="" >
										</td>
									</div>
									<div class="form-group mb-3">
										<td >
											<input name="last_name" id="last_name" placeholder="Last Name" required="required" class="form-control" type="text" size="30" value="" >
										</td>
									</div>
									<div class="form-group mb-3">
										<td>
											<input name="email" placeholder="Enter Your Email" required="required" class="form-control" type="email" size="30" value="">
										</td>
									</div>
									<div class="form-group mb-3">
										<td>
											<input name="mobile" placeholder="Enter Your Mobile" required="required" class="form-control" type="text" size="30" value="">
										</td>
									</div>
									<div class="form-group mb-3">
										<td>
											<input name="signupaddress" placeholder="Write Your Full Address" required="required" class="form-control" type="text" size="30" value="">
										</td>
									</div>
									<div class="form-group mb-3" >
										<td>
											<input name="password" id="password-1" required="required"  placeholder="Enter New Password" class="form-control" type="password" size="30" value="">
										</td>
									</div>
									<div class="form-group mb-3">
										<td>
											<select name="admintype" required="required"  class="form-select form-select-lg mb-3">
												<option selected value="manager">Manager</option>
												
											</select>
										</td>
									</div>
									<div>	
										<input name="signup" class="btn btn-primary" type="submit" value="Add Admin!">
									</div>
									<div class="signup_error_msg">
										<?php 
											if (isset($error_message)) {echo $error_message;}
										?>
									</div>							
								</form>
											
						</main>
					</div>
				</div>	
				';
		}

		?>
	</div>
	<footer class="footer fixed-bottom mt-auto py-3 bg-body-tertiary">
		<div class="container">
			<span>
				<h3 class="">Disclaimer</h3>
				<p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
			</span>
		</div>
	</footer>

	<script src="movement.js" charset="utf-8"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>