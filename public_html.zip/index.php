<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fake Sports Gear</title>
  <link href="styles.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <?php
  include("./inclu/Check_connection.php");
  ?>


</head>

<body>
  <nav class="py-2 bg-body-tertiary border-bottom">
    <div class="container d-flex flex-wrap">


      <ul class="nav">
        <li class="nav-item"><a href="./SQL/logIn.php" class="nav-link link-body-emphasis px-2">Login</a></li>
        <li class="nav-item"><a href="./SQL/signUp.php" class="nav-link link-body-emphasis px-2">Sign up</a></li>

      </ul>
    </div>
  </nav>
  <div class="p-5 mb-4 bg-body-tertiary rounded-3">
    <div class="container-fluid py-5">
      <h1 class="display-5 fw-bold">Fake Sports Gear Marketplace</h1>
      <p class="col-md-8 fs-4">Welome to the primary marketplace for all your counterfeit sports gear needs.</p>
    </div>
  </div>
  <div id="myCarousel" class="carousel slide mb-6" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3" class="active" aria-current="true"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="3" aria-label="Slide 4" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="4" aria-label="Slide 5" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="5" aria-label="Slide 6" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="6" aria-label="Slide 7" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="7" aria-label="Slide 8" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="8" aria-label="Slide 9" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="9" aria-label="Slide 10" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="10" aria-label="Slide 11" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="11" aria-label="Slide 12" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="12" aria-label="Slide 13" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="13" aria-label="Slide 14" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="14" aria-label="Slide 15" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="15" aria-label="Slide 16" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="16" aria-label="Slide 17" class=""></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item">
        <img src="./Images/Website Images/FSG Sign UP.png" class="d-block w-100 border border-primary">
        <div class="container">
          <div class="carousel-caption text-start">
            <h1 style="color:black">Sign Up Today!</h1>
            <p class="opacity-75" style="color:black">Become a part of the community.</p>
            <p><a class="btn btn-lg btn-primary" href="./SQL/signUp.php">Sign up today</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./Images/Website Images/FSG Log In.png" class="d-block w-100 border border-secondary">
      </div>
      <div class="carousel-item active">
        <img src="./Images/Website Images/FSG user Index.png" class="d-block w-100 border border-success">
        <div class="container">
          <div class="carousel-caption text-end">
            <h1 style="color:black">Sign Up Today!</h1>
            <p class="opacity-75" style="color:black">Become a part of the community.</p>
            <p><a class="btn btn-lg btn-primary" href="./SQL/signUp.php">Sign up today</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Add A Product.png" class="d-block w-100 border border-primary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Add an Admin.png" class="d-block w-100 border border-secondary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Add Products.png" class="d-block w-100 border border-success">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Admin Home.png" class="d-block w-100 border border-primary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/All Products.png" class="d-block w-100 border border-secondary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Admin Login.png" class="d-block w-100 border border-success">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Edit an Order.png" class="d-block w-100 border border-primary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Edit Product.png" class="d-block w-100 border border-secondary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Hats.png" class="d-block w-100 border border-success">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Jerseys.png" class="d-block w-100 border border-primary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Ordering History.png" class="d-block w-100 border border-secondary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Sales History.png" class="d-block w-100 border border-success">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/Shoes.png" class="d-block w-100 border border-primary">
      </div>
      <div class="carousel-item">
        <img src=" ./Images/Website Images/tShirts.png" class="d-block w-100 border border-secondary">
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>

    <footer class="footer  mt-auto py-3 bg-body-tertiary">
      <div class="container">
        <span>
          <h3 class="">Disclaimer</h3>
          <p class="lead">This site is only for demonstrative purposes only. No products are to be bought or sold</p>
        </span>
      </div>
    </footer>

    <script src="movement.js" charset="utf-8"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>